<?php

namespace App\Http\Controllers\BackEnd\Downloads;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class DownloadDescriptionController extends Controller
{
    //
}
