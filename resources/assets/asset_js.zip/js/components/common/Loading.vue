<template>
    <div id="loading"><img width="100px" src="/img/static/loading.gif"/></div>
</template>

<style>
    #loading{position:absolute;top:30%;left:50%;right:50%;z-index:100}
</style>